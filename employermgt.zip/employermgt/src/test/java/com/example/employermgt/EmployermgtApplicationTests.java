package com.example.employermgt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployermgtApplicationTests {

	@Test
	void contextLoads() {
	}

}
